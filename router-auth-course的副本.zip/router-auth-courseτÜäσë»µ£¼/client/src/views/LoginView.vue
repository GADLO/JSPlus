<template>
  <div>
    <h1>登录</h1>
    <p>
      <input 
        type="text"
        placeholder="用户名"
        v-model="username"
      />
    </p>
    <p>
      <input 
        type="password"
        placeholder="密码"
        v-model="password"
      />
    </p>
    <p>
      <router-link to="/register">注册</router-link>
    </p>
    <p>
      <button @click="submitLogin">登录</button>
    </p>
  </div>
</template>

<script setup lang="ts">
  import { useLogin, useStorage } from './hooks/user';
  import errorHandler from '@/config/errorHandler';
  import { useRouter } from 'vue-router';

  const {
    username,
    password,
    checkUserInfo,
    submitUserInfo
  } = useLogin();

  const {
    setUserStorage
  } = useStorage();

  const router = useRouter();
  
  const submitLogin = async () => {
    if (!checkUserInfo(username, 6)) {
      alert('用户名长度不小于6位');
      return;
    }

    if (!checkUserInfo(password, 6)) {
      alert('密码长度不小于6位');
      return;
    }

    try {
      const { err_code, data } = await submitUserInfo();

      if (err_code) {
        alert(errorHandler[err_code]);
        return; 
      }

      setUserStorage(data.access_token, data.level);

      router.push('/');
    } catch (err) {
      alert('登录失败');
    }
  }
</script>
