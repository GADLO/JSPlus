<template>
  <div>
    <h1>Home</h1>
    <a href="javascript:;" @click="logout">退出登录</a>
  </div>
</template>

<script setup lang="ts">
  import { useRouter } from 'vue-router';
  import { useStorage } from './hooks/user';

  const router = useRouter();
  const { removeUserStorage } = useStorage();

  const logout = () => {
    removeUserStorage();
    router.push('/login');
  }
</script>
