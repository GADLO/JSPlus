<template>
  <router-view/>
</template>

<script setup lang="ts">
  import { useRouter } from 'vue-router';
import { Storage } from './libs/utils';
import { checkLoginService } from './services/User';
import { useStorage } from './views/hooks/user';

  const router = useRouter();

  const { removeUserStorage } = useStorage();

  router.beforeEach(async (to, from) => {
    const accessToken = Storage.get('access_token');

    if (accessToken) {
      const { err_code } = await checkLoginService();

      if (err_code && to.name === 'home') {
        removeUserStorage();
        return {
          name: 'login'
        }
      }

      if (!err_code && (to.name === 'login' || to.name === 'register')) {
        return {
          name: 'home'
        }
      }

      if (err_code && to.name === 'login') {
        removeUserStorage();
      }

    } else {
      if (to.name !== 'login' && to.name !== 'register') {
        return {
          name: 'login'
        }
      }
    }
  })
</script>
